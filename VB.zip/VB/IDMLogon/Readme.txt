This sample provides a means for keeping the desktop logged on 
to an IDM library.  After the initial logon, the application 
appears in the tool tray, where it can subsequently be used to 
log off the IDM library.  

During logon, the user is given a choice of available IDM libraries.
Once the logon is complete, the application is moved to the tool tray.
Clicking on its icon there brings up a form for either logging off 
the library or changing the user's password.   

The application is terminated by closing its window.  The application
will automatically execute a logoff at this point if the user has 
not already done so. 