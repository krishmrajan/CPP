/** 
 * OCCI Demo - Oracle Database Library
 * A simple test class for the dbLibrary
 * 
 * See http://tardate.blogspot.com/2007/06/mq-and-occi-demo.html
 * Prepared by Paul Gallagher <gallagher.paul@gmail.com>
 * $Id: dblibrary_test.cpp,v 1.3 2007/06/08 23:03:38 paulg Exp $
 */


#include <iostream>
#include <sstream>
#include "dblibrary.h"


using namespace std;


int main (void)
{

	const string user = "OCCIMQDEMO";
	const string passwd = "OCCIMQDEMO";
	const string db = "OCCIMQDEMO";
	int rc;
	int craneId;
	int jobId;
	string jobStatusInformation;
	string jobDescription;

	cout << "*-- Testing dbLibary class" << endl;
	dbLibrary *demo = new dbLibrary (user, passwd, db);

	cout << endl << "*-- Testing getNextJob" << endl;
	craneId = 1;
	cout << "*--   [IN]  craneId              =" << craneId << endl;
	rc = demo->getNextJob ( craneId, &jobId, &jobDescription);
	cout << "*-- getNextJob returns.." << endl;
	cout << "*--   [OUT] rc                   =" << rc << endl;
	cout << "*--   [OUT] jobId                =" << jobId << endl;
	cout << "*--   [OUT] jobDescription       =" << jobDescription << endl;
	
	cout << endl << "*-- Testing markJobComplete" << endl;
	jobStatusInformation = "Dummy job status information set by test program";
	cout << "*--   [IN]  craneId              =" << craneId << endl;
	cout << "*--   [IN]  jobId                =" << jobId << endl;
	cout << "*--   [IN]  jobStatusInformation =" << jobStatusInformation << endl;
	rc = demo->markJobComplete ( craneId, jobId, jobStatusInformation );
	cout << "*-- markJobComplete returns.." << endl;
	cout << "*--   [OUT] rc                   =" << rc << endl;
	
	cout << endl << "*-- Testing doTestProcedure" << endl;
	string queueId = "PRODUCER.Q1";
	string msgId = "DUMMY_MSG";
	string msgText = "Dummy message text set by test program";
	cout << "*--   [IN]  queueId              =" << queueId << endl;
	cout << "*--   [IN]  msgId                =" << msgId << endl;
	cout << "*--   [IN]  msgText              =" << msgText << endl;
	rc = demo->doTestProcedure ( queueId, msgId, msgText );
	cout << "*-- doTestProcedure returns.." << endl;
	cout << "*--   [OUT] rc                   =" << rc << endl;

	cout << endl << "*-- Testing doTestProcedure (intensive 1000 calls)" << endl;
	for (int i = 0; i < 1000; i++) {
		ostringstream itos;
		itos << i;
		rc = demo->doTestProcedure ( queueId, itos.str() , msgText );
		if (rc != 0)
			cout << "Error in " << queueId << " msg " << i << " rc=" << rc << endl;
	}

	delete (demo);
	cout << endl << "*-- Testing dbLibary class - done" << endl;
	exit(0);
} // end of main ()
