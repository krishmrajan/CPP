/** 
 * OCCI Demo - Oracle Database Library
 * dblibrary.cpp is the implementation of a basic C++ Data Access Class (dbLibrary)
 * This class may be replaced by the dblibrary_stub.cpp which
 * provides a dummy implementation to allow testing without any
 * database support linked into the project.
 *
 * - If compiler flag VERBOSE is defined, will produce detailed
 *   status information on stdout
 * - all errors go to stdout and marked with "ERROR:" prefix
 *
 * See http://tardate.blogspot.com/2007/06/mq-and-occi-demo.html
 * Prepared by Paul Gallagher <gallagher.paul@gmail.com>
 * $Id: dblibrary.cpp,v 1.5 2007/06/08 23:58:54 mqm Exp $
 */

#include <iostream>
#include <stdexcept>
#include <occi.h>
#include "dblibrary.h"

using namespace oracle::occi;
using namespace std;

// statement cache tags
const string getNextJobTag = "getNextJobTag";
const string markJobCompleteTag = "markJobCompleteTag";
const string doTestProcedureTag = "doTestProcedureTag";

// TAF callback function
int taf_callback(Environment *env, Connection *conn, void *ctx,  \
Connection::FailOverType foType, Connection::FailOverEventType foEvent)
{

	#ifdef VERBOSE
	cout << "TAF [Callback] Called " << endl;
	#endif

	cout << "Failover Event : " ;
	switch(foEvent)
	{
		case Connection::FO_END   : cout << "FO_END" << endl;
		                         break;
		case Connection::FO_ABORT : cout << "FO_ABORT" << endl;
		                         break;
		case Connection::FO_REAUTH: cout << "FO_REAUTH" << endl;
		                         break;
		case Connection::FO_BEGIN : cout << "FO_BEGIN" << endl;
		                         break;
		case Connection::FO_ERROR : cout << "FO_ERROR" << endl;
		                         break;
		default                   : cout << "Default " << endl;
		                         break;
	}  
	cout << "Failover Type : " ;
	switch(foType)
	{
		case Connection::FO_NONE   : cout << "FO_NONE" << endl;
		                          break;
		case Connection::FO_SESSION: cout << "FO_SESSION" << endl;
		                          break;
		case Connection::FO_SELECT : cout << "FO_SELECT" << endl;
		                          break;
		default                    : cout << "Default " << endl;
		                          break;
	}
	if (foEvent == Connection::FO_ERROR)
		return FO_RETRY;
	if (foEvent == Connection::FO_END)
	{
		cout << "TAF-FO: Failover complete" << endl;
		return 0;
	}
	return 0;
}


// dbLibrary definition
dbLibrary::dbLibrary (string user, string passwd, string connectStr)
{

	#ifdef VERBOSE
	cout << "-*- dbLibrary constructor." << endl;
	cout << "-*-   [IN]  user                 =" << user << endl;
	cout << "-*-   [IN]  passwd               =XXXXX" << endl;
	cout << "-*-   [IN]  connectStr           =" << connectStr << endl;
	#endif

	unsigned int maxConn = 5;
	unsigned int minConn = 0;
	unsigned int incrConn = 1;
	unsigned int stmtCacheSize = 3;

	try
	{
		env = Environment::createEnvironment (Environment::DEFAULT);
		// or, to ensure a multi-threaded safe Environment (env does mutexing): 
		// env = Environment::createEnvironment (Environment::THREADED_MUTEXED);
	
		try
		{
			// Create a homogenous connection pool
			scPool = env->createStatelessConnectionPool
					  (user, passwd, connectStr, 
					  maxConn, minConn, incrConn, 
					  StatelessConnectionPool::HOMOGENEOUS);
		}
		catch(SQLException& ex)
		{
			cout<<"ERROR: SQL Exception thrown."<<endl;
			cout<<"Error number: "<<  ex.getErrorCode()<<endl;
			cout<<ex.getMessage() << endl;

			// this shouldn't really be necessary, but if connection pool
			// creation has failed due to db unavailable, scPool is
			// still defined, yet any attempt to call a method on
			// scPool generates a segmentation fault.
			// By nullifying the scPool handle we avoid that problem
			scPool = 0;
		}

		if (scPool) {
			#ifdef VERBOSE
			cout<<"SUCCESS - createStatelessConnectionPool"<<endl;
			// Show the connection pool parameters
			cout<<"BusyConn="<<scPool->getBusyConnections()<<endl;
			cout<<"OpenConn="<<scPool->getOpenConnections()<<endl;
			cout<<"MaxConn="<<scPool->getMaxConnections()<<endl;
			cout<<"MinConn="<<scPool->getMinConnections()<<endl;
			cout<<"IncrConn="<<scPool->getIncrConnections()<<endl;
			#endif

			//Enabling the cache on the pool
			scPool->setStmtCacheSize(stmtCacheSize);
			#ifdef VERBOSE
			unsigned size = scPool->getStmtCacheSize();
			cout<<"The size of cache for pool is "<< size<<endl;
			#endif

		} else {
			throw runtime_error("connection pool not available");
		}

	}
	catch(SQLException& ex)
	{
		cout<<"ERROR: SQL Exception thrown."<<endl;
		cout<<"Error number: "<<  ex.getErrorCode()<<endl;
		cout<<ex.getMessage() << endl;
	}
	catch(exception& ex)
	{
		cout<<"ERROR: General exception thrown."<<endl;
		cout<<ex.what() << endl;
	}
}


dbLibrary::~dbLibrary ()
{

	try {
		// Destroy the connection pool
		if (scPool) env->terminateStatelessConnectionPool (scPool);
	}
	catch(exception& ex) {}
	try {
		Environment::terminateEnvironment (env);
	}
	catch(exception& ex) {}
	#ifdef VERBOSE
	cout << "-*- dbLibrary stub destroyed." << endl;
	#endif

}


int dbLibrary::getNextJob(
                int craneId,
                int * jobId,
                string * jobDescription)
{
	int rc = 99;

	#ifdef VERBOSE
	cout << "-*- dbLibrary::getNextJob called." << endl;
	cout << "-*-   [IN]  craneId              =" << craneId << endl;
	#endif

	try
	{
		if (!scPool) throw runtime_error("connection pool not available");
		Connection *conn = scPool->getConnection();
		if (!conn) throw runtime_error("connection not available");

		//Registering the Connection for TAF Callback.
		#ifdef VERBOSE
		cout << "Registering the Connection with the TAF Callback" << endl;
		#endif
		conn->setTAFNotify(taf_callback,NULL);

		string sqlStmt = "BEGIN getNewJob(:1, :2, :3); END;";
		Statement *stmt = conn->createStatement (sqlStmt, getNextJobTag);
		stmt->setInt(1, craneId);
		stmt->registerOutParam(2, OCCIINT, sizeof(jobId));
		stmt->registerOutParam(3, OCCISTRING, 2000, "");

		try
		{	
			int rowsUpdated = stmt->executeUpdate ();
			if ( rowsUpdated == 1 ) rc=0;
	
			#ifdef VERBOSE
			cout << "-*-   rowsUpdated                =" << rowsUpdated << endl;
			#endif
		
			*jobId = stmt->getInt (2);
			*jobDescription = stmt->getString (3);
	
			conn->commit();
		}
		catch(SQLException& ex)
		{
			cout<<"ERROR: SQL Exception thrown "<<endl;
			cout<<"Error number: "<<  ex.getErrorCode()<<endl;
			cout<<ex.getMessage() << endl;
			conn->rollback();
		}

		conn->terminateStatement (stmt, getNextJobTag);
		scPool->releaseConnection(conn);

	}
	catch(SQLException& ex)
	{
		cout<<"ERROR: SQL Exception thrown "<<endl;
		cout<<"Error number: "<<  ex.getErrorCode()<<endl;
		cout<<ex.getMessage() << endl;
	}
	catch(exception& ex)
	{
		cout<<"ERROR: General exception thrown."<<endl;
		cout<<ex.what() << endl;
	}

	#ifdef VERBOSE
	cout << "-*-   [OUT] jobId                =" << *jobId << endl;
	cout << "-*-   [OUT] jobDescription       =" << *jobDescription << endl;
	cout << "-*-   [OUT] rc                   =" << rc << endl;
	#endif

	return rc;
}


int dbLibrary::markJobComplete(
            int craneId,
            int jobId,
            string jobStatusInformation)
{
	int rc = 99;

	#ifdef VERBOSE
	cout << "-*- dbLibrary::markJobComplete called." << endl;
	cout << "-*-   [IN]  craneId              =" << craneId << endl;
	cout << "-*-   [IN]  jobId                =" << jobId << endl;
	cout << "-*-   [IN]  jobStatusInformation =" << jobStatusInformation << endl;
	#endif

	try
	{
		if (!scPool) throw runtime_error("connection pool not available");
		Connection *conn = scPool->getConnection();
		if (!conn) throw runtime_error("connection not available");

		//Registering the Connection for TAF Callback.
		#ifdef VERBOSE
		cout << "Registering the Connection with the TAF Callback" << endl;
		#endif
		conn->setTAFNotify(taf_callback,NULL);

		string sqlStmt = "UPDATE jobs SET dt_completed=sysdate, status=2, job_statusinfo=:1 WHERE job_id=:2 and crane_id=:3";
		Statement *stmt = conn->createStatement (sqlStmt, markJobCompleteTag);
		stmt->setString(1, jobStatusInformation);
		stmt->setInt(2, jobId);
		stmt->setInt(3, craneId);
	
		try {
			int rowsUpdated = stmt->executeUpdate ();
			if ( rowsUpdated == 1 ) rc=0;	

			#ifdef VERBOSE
			cout << "-*-   rowsUpdated                =" << rowsUpdated << endl;
			#endif
		
			conn->commit();
		}
		catch(SQLException& ex)
		{
			cout<<"ERROR: SQL Exception thrown "<<endl;
			cout<<"Error number: "<<  ex.getErrorCode()<<endl;
			cout<<ex.getMessage() << endl;
			conn->rollback();
		}
	
		conn->terminateStatement (stmt, markJobCompleteTag);
		scPool->releaseConnection(conn);

	}
	catch(SQLException& ex)
	{
		cout<<"ERROR: SQL Exception thrown "<<endl;
		cout<<"Error number: "<<  ex.getErrorCode()<<endl;
		cout<<ex.getMessage() << endl;
	}
	catch(exception& ex)
	{
		cout<<"ERROR: General exception thrown."<<endl;
		cout<<ex.what() << endl;
	}


	#ifdef VERBOSE
	cout << "-*-   [OUT] rc                   =" << rc << endl;
	#endif

	return rc;
}


int dbLibrary::doTestProcedure(
            string queueId,
            string msgId,
            string msgText)
{
	int rc = 99;

	#ifdef VERBOSE
	cout << "-*- dbLibrary::doTestProcedure called." << endl;
	cout << "-*-   [IN]  queueId              =" << queueId << endl;
	cout << "-*-   [IN]  msgId                =" << msgId << endl;
	cout << "-*-   [IN]  msgText              =" << msgText << endl;
	#endif

	try {

		if (!scPool) throw runtime_error("connection pool not available");
		Connection *conn;
		try {
			conn = scPool->getConnection();
		}
		catch(SQLException& ex) {
			throw runtime_error("connection not available");
		}
		//Registering the Connection for TAF Callback.
		#ifdef VERBOSE
		cout << "Registering the Connection with the TAF Callback" << endl;
		#endif
		conn->setTAFNotify(taf_callback,NULL);

		// NB: optimise the insert with append hint
		string sqlStmt = "INSERT /*+ APPEND */ INTO mqtest1(id,queue_id,msg_id,dt_in,msg_text) VALUES(t1_id_seq.nextval,:1,:2,sysdate,:3)";
		Statement *stmt = conn->createStatement (sqlStmt, doTestProcedureTag);
		stmt->setString(1, queueId);
		stmt->setString(2, msgId);
		stmt->setString(3, msgText);

		try {
			int rowsInserted = stmt->executeUpdate ();
			if ( rowsInserted == 1 ) rc=0;

			#ifdef VERBOSE
			cout << "-*-   rowsInserted               =" << rowsInserted << endl;
			#endif

			conn->commit();
		}
		catch(SQLException& ex)
		{
			cout<<"ERROR: SQL Exception thrown in executeUpdate for:"<<endl;
			cout<<"[queueId=" << queueId <<"] [msgId="<< msgId <<"]"<<endl;
			cout<<"Error number: "<<  ex.getErrorCode()<<endl;
			cout<<ex.getMessage() << endl;
			conn->rollback();
		}

		conn->terminateStatement (stmt, doTestProcedureTag);
		scPool->releaseConnection(conn);
	}
	catch(SQLException& ex)
	{
		cout<<"ERROR: SQL Exception thrown "<<endl;
		cout<<"Error number: "<<  ex.getErrorCode()<<endl;
		cout<<ex.getMessage() << endl;
	}
	catch(exception& ex)
	{
		cout<<"ERROR: General exception thrown."<<endl;
		cout<<ex.what() << endl;
	}

	#ifdef VERBOSE
	cout << "-*-   [OUT] rc                   =" << rc << endl;
	#endif

	return rc;
}

