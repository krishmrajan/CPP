/** 
 * OCCI/MQ Demo - WebSphere MQ "producer" process
 *
 * See http://tardate.blogspot.com/2007/06/mq-and-occi-demo.html
 * Prepared by Paul Gallagher <gallagher.paul@gmail.com>
 * $Id: mqproducer.cpp,v 1.5 2007/06/09 01:24:40 paulg Exp $
 */
//
//
// Description:   
// - C++ WebSphere MQ Message Producer
// - Puts a message to target named queue
// - Expects reply with the same message payload from Consumer
// - Tracks time taken for round-trip
// - Runs continuously with no think-time until condition met for halt
// - Condition for halt: time for load test
//
// - changed queue name parameters to require fully specified queue name
// - changed to continue on error, rather than quit
// - added msgIdAsString function (in mqcommon.h)
// - added support for VERBOSE directive. verbose messages go to stdout
// - all errors go to stdout and marked with "ERROR:" prefix
//
//  This file is based on the IBM sample "imqsput.cpp: distributed with Websphere MQ with the following copyright:
//  <N_OCO_COPYRIGHT> 
//  Licensed Materials - Property of IBM
//  
//  63H9336
//  (c) Copyright IBM Corp. 1994, 2005 All Rights Reserved.
//  
//  US Government Users Restricted Rights - Use, duplication or
//  disclosure restricted by GSA ADP Schedule Contract with
//  IBM Corp.
//  <NOC_COPYRIGHT>  

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <sys/time.h>

#include "mqcommon.h" // WebSphere MQ Common + MQI

using namespace std;


// parameters and static globals
const int MAX_BUFF_SIZE = 2200;
int instNum;
int runDuration;
long thinktime;


// queue objects
ImqQueueManager mgr;                 // Queue manager
ImqQueue targetQueue, replyToQueue;  // Queue
ImqMessage msg;                      // Data message

// instrumented values
unsigned long msgSent = 0, msgRcvd =0;

  
void parseArgs(int argc, char * * argv) {
	
	if (argc != 7) {
		cout << "Required parameters missing" << endl;
		cout << "MQProducer has 6 parameters:" << endl;
		cout << "- the name of the queue manager (required)" << endl;
		cout << "- the name of the request [consumer] queue (required)" << endl;
		cout << "- the name of the reply [producer] queue (required)" << endl;
		cout << "- the program exit time in seconds (required)" << endl;
		cout << "- the int representing this instance (required)" << endl;
		cout << "- the think time between message puts in seconds (required)" << endl;
		exit ((int)99);
	}
	else {
		mgr.setName( argv[1] );
		targetQueue.setName( ((string)argv[2]).c_str() );
		replyToQueue.setName( ((string)argv[3]).c_str() );
		runDuration = atoi(argv[4]);
		instNum     = atoi(argv[5]);
		thinktime   = atol(argv[6]);
	}
	
	#ifdef VERBOSE
	cout << "queueMgr=" << mgr.name() << endl;
	cout << "targetQueue=" << targetQueue.name() << endl;
	cout << "replyToQueue=" << replyToQueue.name() << endl;
	cout << "runDuration=" << runDuration << " secs" <<endl;
	cout << "instNum=" << instNum <<endl;
	cout << "thinktime=" << thinktime <<endl;
	#endif

}

void prepareTextData() {

	string textdata = "this is the OCCI/MQ sample message\n";
	
	//Prepare the Message
	msg.write(textdata.length(), textdata.c_str());
	msg.setFormat( MQFMT_STRING );
	msg.setMessageLength( textdata.length() );
	msg.setReplyToQueueManagerName(mgr.name());
	msg.setReplyToQueueName(replyToQueue.name());
	msg.setMessageType(MQMT_REQUEST);
  	
}

void openConnections() {
	// Connect to queue manager
	if ( ! mgr.connect( ) ) {
		/* stop if it failed */
		cout<<"ERROR: ImqQueueManager("<<mgr.name()  
			<<")::connect ended with reason code " 
			<< (int)mgr.reasonCode() << endl;
		exit( (int)mgr.reasonCode( ) );
	}
	
	// TargetQueue = ie CONSUMER.Qx
	// Associate targetQueue with queue manager.
	targetQueue.setConnectionReference( mgr );
	// Open the target message queue for output
	targetQueue.setOpenOptions( MQOO_OUTPUT + MQOO_INQUIRE  /* open queue for output */
								+ MQOO_FAIL_IF_QUIESCING ); /* but not if MQM stopping */
	targetQueue.open( );
	/* report reason, if any; stop if failed */
	if ( targetQueue.reasonCode( ) ) {
		cout<<"ERROR: ImqQueue("<<targetQueue.name()
			<<")::open ended with reason code "
			<<(int)targetQueue.reasonCode() << endl;
	}
	if ( targetQueue.completionCode( ) == MQCC_FAILED ) {
		cout<<"ERROR: ImqQueue("<<targetQueue.name()
			<<"):: unable to open queue for output" << endl;
	}
	
	// ReplyToQueue = ie PRODUCER.Qx
	// Associate queue with queue manager.
	replyToQueue.setConnectionReference( mgr );

	// Open the named message queue for input; exclusive or shared
	// use of the queue is controlled by the queue definition here
	replyToQueue.setOpenOptions(MQOO_INPUT_AS_Q_DEF + MQOO_INQUIRE /* open queue for input */
                 + MQOO_FAIL_IF_QUIESCING /* but not if MQM stopping */
				);          
	replyToQueue.open( );
	/* report reason, if any; stop if failed      */
	if ( replyToQueue.reasonCode( ) ) {
		cout<<"ERROR: ImqQueue("<<replyToQueue.name()
			<<")::open ended with reason code "
			<<(long)replyToQueue.reasonCode() << endl;
	}
	if ( replyToQueue.completionCode( ) == MQCC_FAILED ) {
		cout<<"ERROR: ImqQueue("<<replyToQueue.name()
			<<") unable to open queue for input" << endl;
	}

}

void closeConnections() {
	// Close the targetQueue
	if ( ! targetQueue.close( ) ) {
		/* report reason, if any     */
		cout<<"ERROR: ImqQueue("<<targetQueue.name()
			<<")::close ended with reason code "
			<<(int)targetQueue.reasonCode() << endl;
	}
	
	// Close the replyToQueue
	if ( ! replyToQueue.close( ) ) {
		/* report reason, if any     */
		cout<<"ERROR: ImqQueue("<<replyToQueue.name()
			<<")::close ended with reason code "
			<<(int)replyToQueue.reasonCode() << endl;
	}

	// Disconnect from MQM if not already connected (the
	// ImqQueueManager object handles this situation automatically)
	if ( ! mgr.disconnect( ) ) {
		/* report reason, if any     */
		cout<<"ERROR: ImqQueueManager("<<mgr.name()
			<<")::disconnect ended with reason code "
			<<(int)mgr.reasonCode() << endl;
	}	
}

double diffTime(timeval tvStr, timeval tvEnd) {
	double diff;
	if ( tvEnd.tv_usec < tvStr.tv_usec ) {			
		long int s = (tvEnd.tv_sec-1)-(tvStr.tv_sec);
		long int us = (tvEnd.tv_usec + 1000000) - tvStr.tv_usec;
		diff = ((double)us)/1000000 + s;		
	}
	else {
		long int s = tvEnd.tv_sec - tvStr.tv_sec;
		long int us = tvEnd.tv_usec - tvStr.tv_usec;
		diff = ((double)us)/1000000 + s;
	}
	
	return diff;	
}

void milliSleep(long ms) {
	const timespec ts = {ms / 1000, ms % 1000 * 1000000};
	nanosleep(&ts, NULL); 
}


double executeRequestReply() {
	ImqGetMessageOptions gmo;
	ImqMessage msgReply;
	char buffer[MAX_BUFF_SIZE];
	
	//Calculate Elapsed Time
	//time_t start = time(0);
	struct timeval before, after;
	struct timezone tz;
	gettimeofday(&before, &tz);
	//Execute PUT
	msg.setMessageId();
	msg.setCorrelationId();
	if ( ! targetQueue.put( msg ) ) {
		// report reason, if any
		cout<<"ERROR: MQProducer: ImqQueue("<<targetQueue.name()
			<<")::put ended with reason code "
			<<(int)targetQueue.reasonCode() << endl;
	}
	else {
		msgSent++;
		#ifdef VERBOSE
		cout << "Message successfully put into Queue. ID: " << msgIdAsString( msg.messageId() ) << endl;
		#endif
	}

	//Execute GET - expecting reply
	//Get Message Options
	gmo.setOptions( MQGMO_WAIT |   /* wait for new messages */
					MQGMO_FAIL_IF_QUIESCING /* but not if MQM stopping */
					);
	gmo.setWaitInterval( 5000 );   /* 5 second limit for waiting for reply    */

	msgReply.useEmptyBuffer( buffer, sizeof( buffer ) );
	// Set message id to null.  The request message id will be
	// moved to the correlation id for the get.
	msgReply.setMessageId( );
	msgReply.setCorrelationId(msg.messageId());

	//Get the message.
	if ( replyToQueue.get( msgReply, gmo ) ) {
		if ( msgReply.formatIs( MQFMT_STRING ) ) {
			msgRcvd++;
			#ifdef VERBOSE
			cout << "Reply Message ID: " << msgIdAsString( msgReply.messageId() ) << endl;
			cout << "Reply Message Length: " << msgReply.messageLength( ) << endl;
			cout << "Reply Data Length: " << msgReply.dataLength( ) << endl;
			buffer[ msgReply.messageLength( ) ] = 0 ;  /* add terminator */
			cout << "Reply Message Data: <" << msgReply.bufferPointer( ) << ">" << endl;
			#endif

		} else {
			cout << "ERROR: MQProducer: Unexpected non-text message received!" << endl;
			//exit(int(99));
		}
	} else {
		/* report reason, if any */
		if ( replyToQueue.reasonCode( ) == MQRC_NO_MSG_AVAILABLE ) {
			/* special report for normal end */
			cout << "ERROR: MQProducer: No Reply message.  NOT GOOD" << endl;
		} else {
			/* general report for other reasons */
			cout << "ERROR: MQProducer: ImqQueue::get ended with reason code" << (long)replyToQueue.reasonCode() << endl;

			/* treat truncated message as a failure for this sample */
			if ( replyToQueue.reasonCode( ) == MQRC_TRUNCATED_MSG_FAILED ) {
				cout << "ERROR: MQProducer: Truncated Message!" << endl;
			}
		}
	}

	gettimeofday(&after, &tz);
	double diff = diffTime(before, after);
	return diff;
}

int main ( int argc, char * * argv ) {
	
	//Parse the arguments
	parseArgs(argc, argv);
	//Read in the 2Kb text message;
	prepareTextData();

	cout<<"MQProducer inst("<<instNum<<") begins"<<endl;

	//Open and hold onto connections until the end of program
	openConnections();

	//Loops until halt condition is reached
	//halt condition = specified time OR response >= 1

	time_t startTime=time(0); 
	time_t endTime=startTime+(runDuration); 
	double resTime=0;
	double avgTime=0;
	unsigned long iterations = 0;
	while ( time(0) < endTime ) {
		resTime = executeRequestReply();
		avgTime = (avgTime * iterations + resTime) / (iterations + 1);
		
		if (resTime > 1) {
			cout<<"response time > 1 = "<<resTime<<endl;
		//} else {
		//	cout<<"response time = "<<resTime<<endl;
		}
		iterations++;
		milliSleep(thinktime);
	}
	
	time_t elapsedTime = time(0)-startTime;
	cout<<"Request/Reply iterations completed = "<<iterations<<" over "<<elapsedTime<<" secs"<<endl;
	cout<<"Number of messages successfully sent = "<<msgSent<<endl;
	cout<<"Number of messages successfully received = "<<msgRcvd<<endl;
	cout<<"Iterations per second = "<<iterations/elapsedTime<<endl;
	cout<<"Average response time per iteration = "<<avgTime<<" secs"<<endl;
	
	//Close connections
	closeConnections();

	cout<<"MQProducer inst("<<instNum<<") ends"<<endl;
	
	return( 0 );
}
