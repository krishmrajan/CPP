/** 
 * OCCI/MQ Demo - WebSphere MQ "consumer" process
 *
 * See http://tardate.blogspot.com/2007/06/mq-and-occi-demo.html
 * Prepared by Paul Gallagher <gallagher.paul@gmail.com>
 * $Id: mqconsumer.cpp,v 1.4 2007/06/10 23:28:44 mqm Exp $
 */
//
// Description:   
// - C++ WebSphere MQ Message Consumer
// - Reads a message from a queue
// - Replies via Reply-to Queue with the same message 
// - Runs continuously until condition met for halt
// - Condition for halt: no more messages after 30 secs
//
// - Integrated dblibrary.h
// - added msgIdAsString function
// - added msgBodyAsString function (in mqcommon.h)
// - added database command args
// - changed queue name parameters to require fully specified queue name
// - added support for VERBOSE directive. verbose messages go to stdout
// - all errors go to stdout and marked with "ERROR:" prefix
// - add dbfactor parameter to limit db operations
//
//  This file is based on the IBM samples "imqsget.cpp" and "imqsput.cpp": distributed with Websphere MQ with the following copyright:
//  <N_OCO_COPYRIGHT> 
//  Licensed Materials - Property of IBM
//  
//  63H9336
//  (c) Copyright IBM Corp. 1994, 2005 All Rights Reserved.
//  
//  US Government Users Restricted Rights - Use, duplication or
//  disclosure restricted by GSA ADP Schedule Contract with
//  IBM Corp.
//  <NOC_COPYRIGHT>  

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>
#include <sstream>
#include <sys/time.h>
#include "dblibrary.h"

using namespace std;

#include "mqcommon.h"


// parameters and static globals
const int MAX_BUFF_SIZE = 2200;
string db_uid = "OCCIMQDEMO";
string db_pwd = "OCCIMQDEMO";
string db_conn = "";
int db_wfactor = 1;
int instNum,timeout;

// database library handle
dbLibrary *dbLib;

// queue objects
ImqQueueManager mgr;                   // Queue manager
ImqQueue incomingQueue, replyToQueue;  // Queue
ImqMessage msg;                        // Data message

// instrumented values
unsigned long iterations = 0, msgRcvd =0, msgSent = 0, dbSavedMsg = 0, dbWriteMsg = 0;
double resTime=0;
double avgTime=0;

void parseArgs(int argc, char * * argv) {

	if (argc < 6 | argc > 10) {
		cout << "Required parameters missing" << endl;
		cout << "MQConsumer has 9 parameters:" << endl;
		cout << "- the name of the queue manager (required)" << endl;
		cout << "- the name of the request [consumer] queue (required)" << endl;
		cout << "- the name of the reply [producer] queue (required)" << endl;
		cout << "- the program exit time in seconds (required)" << endl;
		cout << "- the int representing this instance (required)" << endl;
		cout << "- the database connection string (optional, default=" << db_conn << endl;
		cout << "- the database username (optional, default=" << db_uid << endl;
		cout << "- the database password (optional, default=" << db_pwd << endl;
		cout << "- the db write factor; write every x calls (optional, default=" << db_wfactor << endl;
		exit ((int)99);
	}
	else {
		mgr.setName( argv[1] );
		incomingQueue.setName( ((string)argv[2]).c_str() );
		replyToQueue.setName( ((string)argv[3]).c_str() );
		timeout = atoi( argv[4] );
		instNum = atoi( argv[5] );
		if (argc>6) db_conn = (string)argv[6];
		if (argc>7) db_uid = (string)argv[7];
		if (argc>8) db_pwd = (string)argv[8];
		if (argc>9) db_wfactor = atoi( argv[9] );
	}

	#ifdef VERBOSE
	cout << "queueMgr=" << mgr.name() << endl;
	cout << "incomingQueue=" << incomingQueue.name() << endl;
	cout << "replyToQueue=" << replyToQueue.name() << endl;
	cout << "timeout=" << timeout << " secs" <<endl;
	cout << "instNum=" << instNum <<endl;
	cout << "db_conn=" << db_conn <<endl;
	cout << "db_uid=" << db_uid <<endl;
	cout << "db_pwd=" << db_pwd <<endl;
	cout << "db_wfactor=" << db_wfactor <<endl;
	#endif

}


void openConnections() {

	dbLib = new dbLibrary (db_uid, db_pwd, db_conn);

	// Connect to queue manager
	if ( ! mgr.connect( ) ) {
		/* stop if it failed */
		cout<<"ERROR: ImqQueueManager("<<mgr.name()  
			<<")::connect ended with reason code " 
			<< (int)mgr.reasonCode() << endl;
		exit( (int)mgr.reasonCode( ) );
	}

	// IncomingQueue = ie CONSUMER.Qx
	// Associate incomingQueue with queue manager.
	incomingQueue.setConnectionReference( mgr );
	// Open the incoming message queue for input
	incomingQueue.setOpenOptions( MQOO_INPUT_AS_Q_DEF + MQOO_INQUIRE /* open queue for input */ 
								+ MQOO_FAIL_IF_QUIESCING );     /* but not if MQM stopping */
	incomingQueue.open( );
	/* report reason, if any; stop if failed */
	if ( incomingQueue.reasonCode( ) ) {
		cout<<"ERROR: ImqQueue("<<incomingQueue.name()
			<<")::open ended with reason code "
			<<(int)incomingQueue.reasonCode() << endl;
	}
	if ( incomingQueue.completionCode( ) == MQCC_FAILED ) {
		cout<<"ERROR: ImqQueue("<<incomingQueue.name()
			<<"):: unable to open queue for output" << endl;
	}
	
	// ReplyToQueue = ie PRODUCER.Qx
	// Associate queue with queue manager.
	replyToQueue.setConnectionReference( mgr );

	// Open the named message queue for output
	replyToQueue.setOpenOptions( MQOO_OUTPUT + MQOO_INQUIRE /* open queue for output */
								+ MQOO_FAIL_IF_QUIESCING /* but not if MQM stopping */
				);
	replyToQueue.open();
	/* report reason, if any; stop if failed      */
	if ( replyToQueue.reasonCode( ) ) {
		cout<<"ERROR: ImqQueue("<<replyToQueue.name()
			<<")::open ended with reason code "
			<<(long)replyToQueue.reasonCode() << endl;
	}
	if ( replyToQueue.completionCode( ) == MQCC_FAILED ) {
		cout<<"ERROR: ImqQueue("<<replyToQueue.name()
			<<") unable to open queue for input" << endl;
	}
}

void closeConnections() {
	// Close the incomingQueue
	if ( ! incomingQueue.close( ) ) {
		/* report reason, if any     */
		cout<<"ERROR: ImqQueue("<<incomingQueue.name()
			<<")::close ended with reason code "
			<<(int)incomingQueue.reasonCode() << endl;
	}
	
	// Close the replyToQueue
	if ( ! replyToQueue.close( ) ) {
		/* report reason, if any     */
		cout<<"ERROR: ImqQueue("<<replyToQueue.name()
			<<")::close ended with reason code "
			<<(int)replyToQueue.reasonCode() << endl;
	}

	// Disconnect from MQM if not already connected (the
	// ImqQueueManager object handles this situation automatically)
	if ( ! mgr.disconnect( ) ) {
		/* report reason, if any     */
		cout<<"ERROR: ImqQueueManager("<<mgr.name()
			<<")::disconnect ended with reason code "
			<<(int)mgr.reasonCode() << endl;
	}

	delete (dbLib);
}

// TODO: this is also in mqproducer. should refactor into common lib
double diffTime(timeval tvStr, timeval tvEnd) {
        double diff;
        if ( tvEnd.tv_usec < tvStr.tv_usec ) {
                long int s = (tvEnd.tv_sec-1)-(tvStr.tv_sec);
                long int us = (tvEnd.tv_usec + 1000000) - tvStr.tv_usec;
                diff = ((double)us)/1000000 + s;
        }
        else {
                long int s = tvEnd.tv_sec - tvStr.tv_sec;
                long int us = tvEnd.tv_usec - tvStr.tv_usec;
                diff = ((double)us)/1000000 + s;
        }

        return diff;    
}

void executeResponse() {
	//MQBYTE24 MsgId;
	ImqGetMessageOptions gmo;   // Get message options
	ImqPutMessageOptions pmo;   // Put message options
	char buffer[MAX_BUFF_SIZE]; // Message buffer
	ImqMessage msgReply;
	int dbWFactorCount = 0;
	
	// Get messages from the message queue
	// Loop until there is a failure
	msg.useEmptyBuffer( buffer, sizeof( buffer ) - 1 );
		/* buffer size available for GET */
	gmo.setOptions( MQGMO_WAIT | /* wait for new messages */
					MQGMO_FAIL_IF_QUIESCING );
	gmo.setWaitInterval( timeout*1000 );
	
	while ( incomingQueue.completionCode() != MQCC_FAILED ) {
		//Set message id and correlation id to null.  The program
		// takes whatever messages it can get.
		msg.setMessageId( );
		msg.setCorrelationId( );
		if ( incomingQueue.get( msg, gmo ) ) {
			iterations++;
			if ( msg.formatIs( MQFMT_STRING ) ) {

				//Display message received
				buffer[ msg.messageLength( ) ] = 0 ;  /* add terminator */
				#ifdef VERBOSE
				cout << "Incoming Message ID: " << msgIdAsString( msg.messageId() ) << endl;
				cout << "Incoming Message Length: " << msg.messageLength( ) << endl;
				cout << "Incoming Data Length: " << msg.dataLength( ) << endl;
				cout << "Incoming Message Data: <" << msg.bufferPointer( ) << ">" << endl;
				#endif

				if (msg.messageType() != MQMT_REQUEST) {
					cout << "ERROR: Not a request, no reply being sent" << endl;
				} else {
					msgRcvd++;
					#ifdef VERBOSE
					cout << "RQmgr : " << msg.replyToQueueManagerName() << endl;
					cout << "RQueue: " << msg.replyToQueueName()        << endl;
					#endif

					// call db routine with instrumented metrics
					if (++dbWFactorCount >= db_wfactor)
					{
						dbWFactorCount = 0;
						dbWriteMsg++;
						struct timeval before, after;
						struct timezone tz;
						gettimeofday(&before, &tz);
						int rc = dbLib->doTestProcedure ( 
							( char *) incomingQueue.name(), 
							msgIdAsString( msg.messageId() ), 
							msgBodyAsString( msg) );
						if (rc==0) {
							gettimeofday(&after, &tz);
							resTime = diffTime(before, after);
							avgTime = (avgTime * dbSavedMsg + resTime) / (dbSavedMsg + 1);
							dbSavedMsg++;

							if (resTime > 1) {
								cout<<"db response time > 1 = "<<resTime<<endl;
							}
						}
					}

					//Send a reply with 2K message in the request
					msgReply.setMessageType(MQMT_REPLY);
					msgReply.setMessageId();
					msgReply.setCorrelationId(msg.messageId() );

					msgReply.useFullBuffer(buffer, sizeof(buffer));
					msgReply.setFormat(MQFMT_STRING);
					msgReply.setMessageLength(strlen(buffer));

					if (! replyToQueue.put(msgReply, pmo)) {
						cout << "ERROR: ImqQueue::reply put ended with reason code "
							<< replyToQueue.reasonCode( ) << endl;
					} else {
						msgSent++;
						#ifdef VERBOSE
						cout << "Reply message sent(PUT)" << endl;
						#endif
					}
				}
			} else {
				cout << "ERROR: Non-text message received" << endl;
			}
		} else {
			// PG: I have my doubts that this is sufficient to properly terminate
			// report reason, if any
			if ( incomingQueue.reasonCode( ) == MQRC_NO_MSG_AVAILABLE ) {
				/* special report for normal end */
				cout << endl << "No more messages available after " << timeout << " secs." << endl;
			} else {
				/* general report for other reasons */
				cout << endl << "ERROR: ImqQueue::get ended with reason code " << (long)incomingQueue.reasonCode() << endl;
			}
		}
	}//end of while loop

}


int main ( int argc, char * * argv ) {

	//Parse the arguments
	parseArgs(argc, argv);

	cout<<"MQConsumer inst("<<instNum<<") begins"<<endl;

	//Open and hold onto connections until the end of program
	openConnections();

	//Loops until halt condition is reached
	executeResponse();
	cout<<"Request/Reply iterations completed = "<<iterations<<endl;
	cout<<"Number of messages successfully received = "<<msgRcvd<<endl;
	cout<<"Number of messages for database write = "<<dbWriteMsg<<endl;
	cout<<"Number of messages successfully saved to database = "<<dbSavedMsg<<endl;
	cout<<"Number of messages successfully sent = "<<msgSent<<endl;
	cout<<"Average db response time per iteration = "<<avgTime<<" secs"<<endl;

	//Close connections
	closeConnections();

	cout<<"MQConsumer inst("<<instNum<<") ends"<<endl;

	return( 0 );

}
