--
-- OCCI/MQ Demo - occimqdemo schema test
-- See readme.txt for information
--
-- See http://tardate.blogspot.com/2007/06/mq-and-occi-demo.html
-- Prepared by Paul Gallagher <gallagher.paul@gmail.com>
-- $Id: occimqdemo_test.sql,v 1.3 2007/06/08 23:03:38 paulg Exp $
--

prompt occimqdemo schema test
prompt (assumes database connection called occimqdemo)
prompt

conn occimqdemo/occimqdemo@occimqdemo;

set serveroutput on

declare
  crane_id				jobs.crane_id%TYPE;
  job_id				  jobs.job_id%TYPE;
  job_description	  jobs.job_description%type;
begin
	crane_id := 1;
	getNewJob(crane_id, job_id, job_description);
	DBMS_OUTPUT.PUT(' crane_id = ' || crane_id || '	job_id= ' || job_id || '	job_description= ' || job_description);
	DBMS_OUTPUT.NEW_LINE;
end;
/
exit
