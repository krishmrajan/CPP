#!/bin/bash
#
# OCCI/MQ Demo - script to manage MQ queues
# See readme.txt for information
#
# See http://tardate.blogspot.com/2007/06/mq-and-occi-demo.html
# Prepared by Paul Gallagher <gallagher.paul@gmail.com>
# $Id: qcontrol.sh,v 1.6 2007/06/09 01:12:15 paulg Exp $

# usage information
#
usage() {
cat <<EOF

  OCCI/MQ Demo MQ Control Script

  Usage:
    $0 help            ... this message
    $0 initqm          ... create and start the queue manager
    $0 startqm         ... start the queue manager
    $0 stopqm          ... stop the queue manager
    $0 delqm           ... stop and delete the queue manager
    $0 createq qRange  ... create queue/queue range
    $0 qstatus qRange  ... show status of queue/queue range
    $0 clearq qRange   ... clear queue/queue range
    $0 deleteq qRange  ... delete queue/queue range

  Where
    qRange = queue number or range {a | a..b}
             (queue number "a", or queues from "a" to "b")


EOF
  exit
}

# parse cmd args and set some constants
#
cmd=${1:-"help"}
qRange=$2

qMN=1
qmgr="occimq${qMN}"
consumerQueueModel="CONSUMER${qMN}.Q"
producerQueueModel="PRODUCER${qMN}.Q"


# start the queue manager
#
startQm() {
	strmqm $qmgr
}

# stop the queue manager
#
stopQm() {
	endmqm $qmgr
}

# create and start the queue manager
#
initQMgr() {
	crtmqm -q $qmgr
	startQm
}

# delete the queue manager
#
delQMgr() {
	stopQm
	dltmqm $qmgr
}

# create queue
#
createQueue() {
	local qRange=$1
	local qLo=${qRange%%.*}
	local qHi=${qRange##*.}
	local q
	local v_cmd=
	
	for ((q=qLo; q <= qHi ; q++))
	do
	  v_cmd="${v_cmd}define qlocal (${producerQueueModel}$q) DEFPSIST(YES)\ndefine qlocal (${consumerQueueModel}$q) DEFPSIST(YES)\n"
	done
	echo -e "${v_cmd}" | runmqsc $qmgr
}


# show queue status
#
showQueueStatus() {
	local qRange=$1
	local qLo=${qRange%%.*}
	local qHi=${qRange##*.}
	local q
	local v_cmd=
	
	for ((q=qLo; q <= qHi ; q++))
	do
	  v_cmd="${v_cmd}display qstatus (${producerQueueModel}$q)\ndisplay qstatus (${consumerQueueModel}$q)\n"
	done
	echo -e "${v_cmd}" | runmqsc $qmgr
}


# clear queue
#
clearQueue() {
	local qRange=$1
	local qLo=${qRange%%.*}
	local qHi=${qRange##*.}
	local q
	local v_cmd=
	
	for ((q=qLo; q <= qHi ; q++))
	do
	  v_cmd="${v_cmd}clear qlocal (${producerQueueModel}$q)\nclear qlocal (${consumerQueueModel}$q)\n"
	done
	echo -e "${v_cmd}" | runmqsc $qmgr
}


# delete queue
#
deleteQueue() {
	local qRange=$1
	local qLo=${qRange%%.*}
	local qHi=${qRange##*.}
	local q
	local v_cmd=
	
	for ((q=qLo; q <= qHi ; q++))
	do
	  v_cmd="${v_cmd}delete qlocal (${producerQueueModel}$q) PURGE\ndelete qlocal (${consumerQueueModel}$q) PURGE\n"
	done
	echo -e "${v_cmd}" | runmqsc $qmgr
}



# branch to command routine
#
case $cmd in
	initqm|initmq)
		initQMgr
		;;
    delqm|delmq)
		delQMgr
		;;
	start|startmq|startmqm|startqm|strmq|strmqm)
		startQm
		;;
	stop|stopmq|stopmqm|stopqm|end|endmq|endmqm)
		stopQm
		;;
	createq|create)
		createQueue $qRange
		;;
	qstatus|qstat|stat|status)
		showQueueStatus $qRange
		;;
	clearq|clear)
		clearQueue $qRange
		;;
	deleteq|delete|del)
		deleteQueue $qRange
		;;
	*)
		usage
		;;
esac

