--
-- OCCI/MQ Demo - occimqdemo schema initialisation
-- See readme.txt for information
--
-- See http://tardate.blogspot.com/2007/06/mq-and-occi-demo.html
-- Prepared by Paul Gallagher <gallagher.paul@gmail.com>
-- $Id: occimqdemo_init.sql,v 1.3 2007/06/08 23:03:38 paulg Exp $
--

prompt occimqdemo schema initialisation
prompt (assumes database connection called occimqdemo) 

prompt
prompt *** Connect as system to create occimqdemo user
connect system@occimqdemo;

grant connect,resource to occimqdemo identified by occimqdemo;
-- grant create table,create sequence to occimqdemo;

prompt 
prompt ** Connect as occimqdemo to create schema objects
connect occimqdemo/occimqdemo@occimqdemo;

create sequence t1_id_seq start with 1 increment by 1;

create table mqtest1 (
	id				number		NOT NULL,
	queue_id		varchar(50)	NOT NULL,
	msg_id			varchar(155)	NOT NULL,
	dt_in			date		NOT NULL,
	msg_text		varchar(2100)	NOT NULL,
	CONSTRAINT mqtest1_pk PRIMARY KEY(id,queue_id,msg_id)
) INITRANS 20;
-- NB: use INITRANS to avoid 'file header block' contention

create table jobs (
	job_id 			number	CONSTRAINT jobs_pk PRIMARY KEY,
	crane_id		number	NOT NULL,
	status			number	NOT NULL CONSTRAINT jobs_status_ck CHECK (status in (1,2,3)),
	dt_assigned		date	NOT NULL,
	dt_completed		date,
	job_description		varchar(2000),
	job_statusinfo		varchar(2000)
);


create sequence job_id_seq start with 1 increment by 1;


create or replace procedure getNewJob(
	crane_id	IN	jobs.crane_id%TYPE,
	job_id		OUT	jobs.job_id%TYPE,
	job_description	OUT	jobs.job_description%type)
as
begin
	-- abandon any existing jobs
	update jobs j
	set 	j.dt_completed=sysdate, 
		j.status=3,
		j.job_statusinfo=rpad('Abandoned job [pad to 2000 char] ', 2000, '.')
	where j.crane_id=crane_id and j.status = 1;

	-- get new job
	select job_id_seq.nextval 
		into job_id 
		from dual;
	select rpad('This is the job description for job ' || job_id || ' [pad to 2000 char] ', 2000, '.')
		into job_description
		from dual;
	insert into jobs(job_id,crane_id,status,dt_assigned,job_description)
		values(job_id,crane_id,1,sysdate,job_description);
end;
/
show error

exit
