#!/bin/bash
#
# OCCI/MQ Demo - main test runner script
# See readme.txt for information
#
# See http://tardate.blogspot.com/2007/06/mq-and-occi-demo.html
# Prepared by Paul Gallagher <gallagher.paul@gmail.com>
# $Id: loadTest.sh,v 1.8 2007/06/09 01:13:24 paulg Exp $
#

# usage information
#
usage() {
cat <<EOF

  OCCI/MQ Demo Test Runner Script

  Usage:
    $0 help            ... this message
    $0 run qRange pTimeout pThinktime cTimeout
                       ... runs test pairs (producer/consumer) for specified queues
    $0 prod qRange pTimeout pThinktime
                       ... only starts a producer for specified queues
    $0 cons qRange cTimeout
                       ... only starts a consumer for specified queues
    $0 tail qRange     ... tails log files for test programs for specified queues
    $0 report qRange   ... generates report from logfiles for specified queues


  Where
    qRange    = queue number or range {a | a..b}
               (queue number "a", or queues from "a" to "b")
    pTimeout   = producer timeout in seconds (default=120)
    pThinktime = producer message injection delay (default=0)
    cTimeout   = consumer timeout in seconds (default=30)


EOF
  exit
}


# parse cmd args and set some constants
#
cmd=${1:-"help"}
qRange=${2:-1}
pTimeout=${3:-120}
pThinktime=${4:-30}
cTimeout=${5:-30}

qMN=1
qmgr="occimq${qMN}"
consumerQueueModel="CONSUMER${qMN}.Q"
producerQueueModel="PRODUCER${qMN}.Q"

dbWFactor=1
db_conn=OCCIMQDEMO
db_uid=occimqdemo
db_pwd=occimqdemo

# force a log dir
mkdir log 2> /dev/null

startConsumer() {
	local qRange=$1
	local qLo=${qRange%%.*}
	local qHi=${qRange##*.}
	local q

	for ((q=qLo; q <= qHi ; q++))
	do
		bin/mqconsumer ${qmgr} ${consumerQueueModel}${q} ${producerQueueModel}${q} \
		$cTimeout ${q} "${db_conn}" "${db_uid}" "${db_pwd}" ${dbWFactor} > log/mqconsumer${qMN}-${q}.log 2> log/mqconsumer${qMN}-${q}.err &
	done
}


startProducer() {
	local qRange=$1
	local qLo=${qRange%%.*}
	local qHi=${qRange##*.}
	local q

	for ((q=qLo; q <= qHi ; q++))
	do
		bin/mqproducer ${qmgr} ${consumerQueueModel}${q} ${producerQueueModel}${q} \
		$pTimeout ${q} ${pThinktime} > log/mqproducer${qMN}-${q}.log 2> log/mqproducer${qMN}-${q}.err &
	done
}

runTest() {
	local qRange=$1
	local qLo=${qRange%%.*}
	local qHi=${qRange##*.}
	local q

	for ((q=qLo; q <= qHi ; q++))
	do
		startConsumer $q
	done
        for ((q=qLo; q <= qHi ; q++))
        do
                startProducer $q
        done


}

tailLogs() {
	local qRange=$1
	local qLo=${qRange%%.*}
	local qHi=${qRange##*.}
	local q
	local cmd

	if [ "$qRange" == "" ]
	then
		cmd="log/*.log"
	else
		for ((q=qLo; q <= qHi ; q++))
		do
			cmd="${cmd} log/*er${qMN}-${q}.log"
		done
	fi
	tail -f $cmd
}


# produce summary report from log files
#
summaryReport() {
	local qRange=$1
	local qLo=${qRange%%.*}
	local qHi=${qRange##*.}
	local q

	echo "Instance, Producer Iterations, Producer Msg Sent OK, Producer Msg Reply OK, Consumer Iterations, Consumer Msg In OK, Consumer Msg Saved to DB OK, Consumer Msg Out OK, Test Duration(secs), Producer Iterations per second, Average Response Time, Count Response Time > 1, Slowest Response Time > 1, Average DB Response Time, Count DB Response Time > 1, Slowest DB Response Time >1, Producer Errors, Consumer Errors, TAF Failovers"

	for ((q=qLo; q <= qHi ; q++))
	do

		# process the producer log
		#
		f="log/mqproducer${qMN}-${q}.log"

		s=$(grep "Request/Reply iterations completed" $f)
		piter=${s##*= } ; piter=${piter%% *}
		dur=${s##*over } ; dur=${dur%% *}
		s=$(grep "Number of messages successfully sent" $f)
		pmsgout=${s##*= }
		s=$(grep "Number of messages successfully received" $f)
		pmsgin=${s##*= }
		s=$(grep "Iterations per second" $f)
		ips=${s##*= } ; # ips=${ips%% *}
		s=$(grep "Average response time" $f)
		ars=${s##*= } ; ars=${ars% *}

		srt=0
		rtcount=0
		for rt in $(grep "response time > 1" $f | awk '{print $6}')
		do
			((rtcount++))
			srt=$(echo "$rt $srt" | awk '{print ($1 > $2) ? $1 : $2}')
		done

		proderr=$(grep -c "ERROR:" $f)

		# process the producer error log
		#
		f="log/mqproducer${qMN}-${q}.err"
		# nothing to do

		# process the consumer log
		#
		f="log/mqconsumer${qMN}-${q}.log"
		s=$(grep "Request/Reply iterations completed" $f)
		citer=${s##*= }
		s=$(grep "Number of messages successfully received" $f)
		cmsgin=${s##*= }
		s=$(grep "Number of messages successfully sent" $f)
		cmsgout=${s##*= }
		s=$(grep "Number of messages successfully saved to database" $f)
		cdbsaved=${s##*= }
		conserr=$(grep -c "ERROR:" $f)
		ctaffo=$(grep -c "TAF-FO:" $f)
		s=$(grep "Average db response time" $f)
		dbars=${s##*= } ; dbars=${dbars% *}

                dbsrt=0
                dbrtcount=0
                for rt in $(grep "db response time > 1" $f | awk '{print $7}')
                do
                        ((dbrtcount++))
                        dbsrt=$(echo "$rt $dbsrt" | awk '{print ($1 > $2) ? $1 : $2}')
                done

		# process the consumer error log
		#
		f="log/mqconsumer${qMN}-${q}.err"
		# nothing to do

		echo "$q, $piter, $pmsgout, $pmsgin, $citer, $cmsgin, $cdbsaved, $cmsgout, $dur, $ips, $ars, $rtcount, $srt, $dbars, $dbrtcount, $dbsrt, $proderr, $conserr, $ctaffo"


	done

}


# branch to requested operations
#
case $cmd in
	prod)
		startProducer $qRange
		;;
	cons)
		qConsTimeout=${3:-30}
		startConsumer $qRange
		;;
	run|load)
		runTest $qRange
		tailLogs $qRange
		;;
	tail)
		tailLogs $qRange
		;;
	report)
		summaryReport $qRange
		;;
	*)
		usage
		;;
esac
