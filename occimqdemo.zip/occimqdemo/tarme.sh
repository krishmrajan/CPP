#!/bin/bash
#
# OCCI/MQ Demo - script to create archive for distribution
# See readme.txt for information
#
# See http://tardate.blogspot.com/2007/06/mq-and-occi-demo.html
# Prepared by Paul Gallagher <gallagher.paul@gmail.com>
# $Id: tarme.sh,v 1.2 2007/06/08 23:03:38 paulg Exp $
#
tar -czvf occimqdemo.tgz *.sh *.cpp *.h *.mk *.sql *.txt

