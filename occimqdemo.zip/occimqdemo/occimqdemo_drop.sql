--
-- OCCI/MQ Demo - occimqdemo schema drop
-- See readme.txt for information
--
-- See http://tardate.blogspot.com/2007/06/mq-and-occi-demo.html
-- Prepared by Paul Gallagher <gallagher.paul@gmail.com>
-- $Id: occimqdemo_drop.sql,v 1.3 2007/06/08 23:03:38 paulg Exp $
--

prompt occimqdemo schema drop
prompt (assumes database connection called occimqdemo)

prompt
prompt *** Connect as system to cleanup occimqdemo user
connect system@occimqdemo;

drop user occimqdemo cascade
/

exit
