/** 
 * OCCI/MQ Demo - Common WebSphere MQ support
 *
 * See http://tardate.blogspot.com/2007/06/mq-and-occi-demo.html
 * Prepared by Paul Gallagher <gallagher.paul@gmail.com>
 * $Id: mqcommon.h,v 1.3 2007/06/08 23:03:38 paulg Exp $
 */

using namespace std;

#include <imqi.hpp> // WebSphere MQ MQI

string msgIdAsString( ImqBinary messageId );

string msgBodyAsString( ImqMessage msg );

