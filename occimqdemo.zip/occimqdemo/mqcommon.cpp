/** 
 * OCCI/MQ Demo - Common WebSphere MQ support
 *
 * See http://tardate.blogspot.com/2007/06/mq-and-occi-demo.html
 * Prepared by Paul Gallagher <gallagher.paul@gmail.com>
 * $Id: mqcommon.cpp,v 1.3 2007/06/08 23:03:38 paulg Exp $
 */


#include <sstream>
#include "mqcommon.h"

using namespace std;

string msgIdAsString( ImqBinary messageId ) { 

	MQBYTE24 MsgId;
	ostringstream outs;

	messageId.copyOut(MsgId, MQ_MSG_ID_LENGTH, 0);
	outs.setf(ios::hex);
	for (int i=0; i < MQ_MSG_ID_LENGTH; i++) {
		outs << (int)MsgId[i];
	}
	outs.unsetf(ios::hex);

	return outs.str();
}

string msgBodyAsString( ImqMessage msg ) {

	stringstream outs;
	if ( msg.formatIs( MQFMT_STRING ) ) {
		char * buffer = msg.bufferPointer();
		buffer[ msg.messageLength( ) ] = 0 ;  /* add terminator */
		outs << buffer;
	} else {
		outs << "NOT STRING FORMAT";
	}

	return outs.str();
}


