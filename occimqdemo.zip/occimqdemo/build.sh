#!/bin/bash
#
# OCCI/MQ Demo - main build script
# See readme.txt for information
#
# See http://tardate.blogspot.com/2007/06/mq-and-occi-demo.html
# Prepared by Paul Gallagher <gallagher.paul@gmail.com>
# $Id: build.sh,v 1.5 2007/06/09 00:44:54 paulg Exp $
#


# parse cmd args and set some constants
#
cmd=${1:-"help"}

if [ "$2" == "verbose" ]
then
	verbose="VERBOSE=y"
else
	verbose="VERBOSE=n"
fi


# funciton to init directory structure
#
function initDir {
	mkdir bin 2> /dev/null
	mkdir log 2> /dev/null
	rm bin/mq* 2> /dev/null
}

# branch to routine
#
case $cmd in

initdb)
	sqlplus -S /nolog @occimqdemo_init
	;;

testdb)
	sqlplus -S /nolog @occimqdemo_test
	;;

cleandb)
	sqlplus -S /nolog @occimqdemo_clean
	;;

dropdb)
	sqlplus -S /nolog @occimqdemo_drop
	;;

dbstatus)
	sqlplus -S /nolog @occimqdemo_status
	;;

clean)
	initDir
	make -f occimq.mk clean
	;;

stub)
	initDir
	make -f occimq.mk clean
	make -f occimq.mk DB=stub $verbose
	;;

db)
	initDir
	make -f occimq.mk clean
	make -f occimq.mk DB=oracle $verbose
	;;

demodb)
	make -f $ORACLE_HOME/rdbms/demo/demo_rdbms.mk buildocci OBJS="dblibrary.o dblibrary_test.o" EXE=dblibrary_test
	;;

*)
	cat <<EOF

  Demo build script for OCCI/MQ Demo dbLibrary.

  Usage - OCCIMQDEMO Schema Database operations:
    $0 initdb         ... initialise the demo database (create the 
                          occimqdemo user and sample tables)
    $0 testdb         ... simple PL/SQL test of the occimqdemo user
                          and sample tables
    $0 cleandb        ... cleanout all the occimqdemo tables
    $0 dropdb         ... to drop all occimqdemo objects
    $0 dbstatus       ... show db status

  Usage - C++ sample code operations. Generates:

    $0 stub [verbose] ... build the stub sources, optionally with verbose
                          output on if specified
    $0 db [verbose]   ... build the db-integrated sources, optionally with
                          verbose output on if specified
    $0 demodb         ... build the dbLibrary demo using Oracle demo_rdbms.mk
                         (Use this to get platform-specific library info
                          that may need to be updated in occimq.mk)
    $0 clean          ... clean up compiled files


EOF
	;;
esac

