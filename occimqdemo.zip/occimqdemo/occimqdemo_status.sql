--
-- OCCI/MQ Demo - occimqdemo schema status
-- See readme.txt for information
--
-- See http://tardate.blogspot.com/2007/06/mq-and-occi-demo.html
-- Prepared by Paul Gallagher <gallagher.paul@gmail.com>
-- $Id: occimqdemo_status.sql,v 1.3 2007/06/08 23:03:38 paulg Exp $
--

prompt occimqdemo schema status
prompt (assumes database connection called occimqdemo) 
prompt 

conn occimqdemo/occimqdemo@occimqdemo

prompt TEST PROGRAM STATUS
select count(*) as COMPLETED_TESTS from mqtest1;

exit
