/** 
 * OCCI Demo - Oracle Database Library
 * defines the dbLibrary class - a basic C++ Data Access Class
 *
 * Implementation is found in dblibrary.cpp is the implementation.
 * This class may be replaced by the dblibrary_stub.cpp which
 * provides a dummy implementation to allow testing without any
 * database support linked into the project.
 *
 * - If compiler flag VERBOSE is defined, will produce detailed
 *   status information on stdout
 * - all errors go to stdout and marked with "ERROR:" prefix
 *
 * See http://tardate.blogspot.com/2007/06/mq-and-occi-demo.html
 * Prepared by Paul Gallagher <gallagher.paul@gmail.com>
 * $Id: dblibrary.h,v 1.3 2007/06/08 23:03:38 paulg Exp $
 */

using namespace std;

// forward references to eliminate the need for occi.h include
namespace oracle 
{
namespace occi 
{
class  Environment;
class  StatelessConnectionPool;
}
}

/**
 * dbLibrary definition
 */
class  dbLibrary
{
	private:

	oracle::occi::Environment *env;
	oracle::occi::StatelessConnectionPool *scPool;

	public:

	/**
	 * Constructor.
	 * Parameters:
	 *    user       - database username
	 *    passwd     - database user password
	 *    connectStr - connection string
	 * NB: To enable TAF, the connect string has to be configured for failover and 
	 * registered on Connection (created from Environment, ConnectionPool and StatelessConnectionPool). 
	 * Note that TAF support for ConnectionPools does not include BACKUP and PRECONNECT clauses; 
	 * these should not be used in the connect string
	 */
	dbLibrary (string user, string passwd, string connectStr);

	~dbLibrary ();

	int getNextJob(
                    int craneId,
                    int * jobId,
                    string * jobDescription);

 	int markJobComplete(
                    int craneId,
                    int jobId,
                    string jobStatusInformation);

 	int doTestProcedure(
                    string queueId,
                    string msgId,
                    string msgText);

}; // end of dbLibrary

