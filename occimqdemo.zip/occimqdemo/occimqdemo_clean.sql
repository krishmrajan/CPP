--
-- OCCI/MQ Demo - occimqdemo schema cleanup
-- See readme.txt for information
--
-- See http://tardate.blogspot.com/2007/06/mq-and-occi-demo.html
-- Prepared by Paul Gallagher <gallagher.paul@gmail.com>
-- $Id: occimqdemo_clean.sql,v 1.3 2007/06/08 23:03:38 paulg Exp $
--

prompt occimqdemo schema cleanup
prompt (assumes database connection called occimqdemo)

prompt
prompt *** Connect as occimqdemo user to cleanup demo schema
connect occimqdemo/occimqdemo@occimqdemo;

truncate table mqtest1;
truncate table jobs;

exit
