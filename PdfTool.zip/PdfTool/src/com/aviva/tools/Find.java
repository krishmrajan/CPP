package com.aviva.tools;
/* For more information on what constitutes a glob pattern, see
* https://docs.oracle.com/javase/tutorial/essential/io/fileOps.html#glob
*
* The file or directories that match the pattern are printed to
* standard out.  The number of matches is also printed.
*
* When executing this application, you must put the glob pattern
* in quotes, so the shell will not expand any wild cards:
*              java Find . -name "*.java"
*/

import java.io.*;
import java.nio.file.*;
import java.nio.file.attribute.*;

import org.apache.pdfbox.pdmodel.PDDocument; 
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.encryption.InvalidPasswordException;











import static java.nio.file.FileVisitResult.*;
import static java.nio.file.FileVisitOption.*;

import java.util.*;

public class Find {

	
		 public static class Finder
	        extends SimpleFileVisitor<Path> {

	        private final PathMatcher matcher;
	        private int numMatches = 0;
	        private final PDDocument doc = new PDDocument(); 
	        private File tst = null;
	       
		   

	        Finder(String pattern) {
	            matcher = FileSystems.getDefault()
	                    .getPathMatcher("glob:" + pattern);
	        }
	        
	   

	        @SuppressWarnings("static-access")
			// Compares the glob pattern against
	        // the file or directory name.
	        void find(Path file) throws IOException, IOException {
	            Path name = file.getFileName();
	    		//tst = name.toRealPath(LinkOption.NOFOLLOW_LINKS).toFile();	
	            
	            if (name != null && matcher.matches(name)) {
	            	tst = file.toFile();
	                numMatches++;
	                //System.out.println(file);
	                doc.load(tst);
	                System.out.println(file + " no of pages " + doc.getNumberOfPages());
	                doc.close();
	            }
	        }

			// Prints the total number of
	        // matches to standard out.
	        void done() {
	            System.out.println("Matched: "
	                + numMatches);
	        }

	        // Invoke the pattern matching
	        // method on each file.
	        @Override
	        public FileVisitResult visitFile(Path file,
	                BasicFileAttributes attrs) {
	            try {
					find(file);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	            return CONTINUE;
	        }

	        // Invoke the pattern matching
	        // method on each directory.
	        @Override
	        public FileVisitResult preVisitDirectory(Path dir,
	                BasicFileAttributes attrs) {
	            try {
					find(dir);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	            return CONTINUE;
	        }

	        @Override
	        public FileVisitResult visitFileFailed(Path file,
	                IOException exc) {
	            System.err.println(exc);
	            return CONTINUE;
	        }
	    }

		// TODO Auto-generated constructor stub
	}


