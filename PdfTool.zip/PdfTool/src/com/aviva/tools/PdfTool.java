package com.aviva.tools;
import java.io.File;
import java.io.IOException;
 

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.apache.pdfbox.pdmodel.PDDocument; 
import org.apache.pdfbox.pdmodel.PDPage;
//import org.apache.pdfbox.pdmodel.encryption.InvalidPasswordException;

import com.aviva.tools.Find.Finder;

public class PdfTool {

	public PdfTool() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		System.out.println("Helloworld");
		 File file = new File(args[0]); 
	      PDDocument document;
	      document = new PDDocument();
		try {
			document = PDDocument.load(file);
			System.out.println("No of pages " + document.getNumberOfPages());
		      document.close();
		}// catch (InvalidPasswordException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
		//} 
	catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		finally{
		       if(document!=null) //IT GOES FROM STRING X1 STRAIGHT TO HERE.
		    	   document.close();
		}

       /* Path startingDir = Paths.get("D:/downloads");   //Paths.get(args[0]);
        String pattern = args[2];

        Finder finder = new Finder(pattern);
        Files.walkFileTree(startingDir, finder);
        finder.done();*/
	      

	}

}
